export class Customer {
    id: number;
    
    name:string;
    tel: number;
    
    email:string;
    constructor(id:number,  name:string,tel:number, email:string){
       this.id=id;
       this.name=name;
       this.tel=tel;
       this.email=email;
      
    }

}

